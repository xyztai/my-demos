package com.springcloud.sentinel_nacos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SentinelNacosApplication {

    public static void main(String[] args) {
        SpringApplication.run(SentinelNacosApplication.class, args);
    }

}
