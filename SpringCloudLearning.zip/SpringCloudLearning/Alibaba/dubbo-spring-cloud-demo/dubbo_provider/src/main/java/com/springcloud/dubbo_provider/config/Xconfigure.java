package com.springcloud.dubbo_provider.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Configuration;

/**
 * @Author tai
 * @create 2021-08-20 16:39
 */
@Configuration
@EnableAutoConfiguration
public class Xconfigure {
}
