package com.springcloud.dubbo_api.service;

/**
 * @Date: 2019/9/2 16:26
 * @Version: 1.0
 * @Desc:
 */
public interface HelloService {
    String hello(String name);
}
