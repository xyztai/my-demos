package com.springcloud.dubbo_api.config;

/**
 * @Author tai
 * @create 2021-08-20 16:56
 */

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Configuration;

@EnableDiscoveryClient
@EnableAutoConfiguration
@Configuration
public class Xconfigure {
}