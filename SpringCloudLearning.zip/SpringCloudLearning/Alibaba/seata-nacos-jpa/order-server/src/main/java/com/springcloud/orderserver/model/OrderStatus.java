package com.springcloud.orderserver.model;

public enum OrderStatus {
    /**
     * INIT
     */
    INIT,
    /**
     * SUCCESS
     */
    SUCCESS,
    /**
     * FAIL
     */
    FAIL
}
