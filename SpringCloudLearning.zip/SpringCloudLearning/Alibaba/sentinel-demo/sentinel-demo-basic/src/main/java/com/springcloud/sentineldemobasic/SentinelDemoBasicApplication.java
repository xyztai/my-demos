package com.springcloud.sentineldemobasic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SentinelDemoBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(SentinelDemoBasicApplication.class, args);
	}

}
